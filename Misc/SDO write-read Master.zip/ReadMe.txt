SDOMaster.exe needs .net framework V4.0 or higher.

Install the lastest IXXAT VCI driver, this software is capable of using every IXXAT CAN device.

Start the software by executing "startSDOmaster.bat".

This program supports SDO write/read request, it can be used to configure the states of a CANopen device using NMT and it can produce Sync objects to trigger synchronous tasks on a CANopen device.

PDO is not supported, this program is for debug/test use only.

Software tested on windows XP SP3.


Author: Pim van den Berg, the Netherlands