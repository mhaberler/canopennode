/**
 ******************************************************************************
 * @file    led.h
 * @author  VJ
 * @version v1.0
 * @date    21-Nov-2012
 * @brief   led file header
 ******************************************************************************
 */

#ifndef __LED_H
#define __LED_H

/* Includes ------------------------------------------------------------------*/
#include "common.h"
#include "stm32f10x.h"
#include "stdint.h"

/* Exported define -----------------------------------------------------------*/

#define RCC_APB2Periph_GPIO_LED      RCC_APB2Periph_GPIOB

#define LED_1_PORT     GPIOB
#define LED_1_PIN      GPIO_Pin_14

#define LED_2_PORT     GPIOB
#define LED_2_PIN      GPIO_Pin_15

/* Exported variables -----------------------------------------------------------*/

/* Exported functions -----------------------------------------------------------*/
void vLED_InitRCC(void);
void vLED_InitPort(void);
void vLED_OffPB14Led(void);
void vLED_OnPB14Led(void);
void vLED_OffPB15Led(void);
void vLED_OnPB15Led(void);

#endif /* __LED_H */




