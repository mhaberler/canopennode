/**
 ******************************************************************************
 * @file    led.c
 * @author  VJ
 * @version v1.0
 * @date    06-Aug-2013
 * @brief   led source file
 ******************************************************************************
 */

/* Includes ------------------------------------------------------------------*/
#include "led.h"
/* Private macro -------------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private variable ----------------------------------------------------------*/
/* Private function ----------------------------------------------------------*/

/**
 * @brief  LED Initialize RCC
 * @input  None
 * @output None
 * @return None
 *
*/
void vLED_InitRCC(void)
{
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIO_LED, ENABLE);
}

/**
 * @brief  LED Initialize Port
 * @input  None
 * @output None
 * @return None
 *
*/
void vLED_InitPort(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;

  /************ Battery Capacity LED Array ***************/
  vLED_OffPB14Led();                          /* turn off LED (active high)*/
  vLED_OffPB15Led();

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14 | GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;

  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
}

 /**
 * @brief  turn off PB14 led
 * @input  None
 * @output None
 * @return None
 *
*/
void vLED_OffPB14Led(void)
{
  GPIO_ResetBits(LED_1_PORT, LED_1_PIN);
}
 /**
 * @brief  turn off PB15 led
 * @input  None
 * @output None
 * @return None
 *
*/
void vLED_OffPB15Led(void)
{
  GPIO_ResetBits(LED_2_PORT, LED_2_PIN);
}

/**
 * @brief  turn On PB14 led
 * @input  None
 * @output None
 * @return None
 *
*/
void vLED_OnPB14Led(void)
{
  GPIO_SetBits(LED_1_PORT, LED_1_PIN);
}

/**
 * @brief  turn On PB14 led
 * @input  None
 * @output None
 * @return None
 *
*/
void vLED_OnPB15Led(void)
{
  GPIO_SetBits(LED_2_PORT, LED_2_PIN);
}

